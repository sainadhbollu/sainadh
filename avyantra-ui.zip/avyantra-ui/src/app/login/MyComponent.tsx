import {Injector} from '@angular/core';
import * as React from 'react';
import * as ReactDOM from 'react-dom';

interface IReactApplication {
  injector: Injector;
}

class ReactApp extends React.Component<IReactApplication, any> {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        {/* <h2>ReactJS component: </h2> */}
      </div>
    );
  }
}

export default class ReactApplication {

  static initialize(
    containerId: string,
    injector: Injector
  ) {
    ReactDOM.render(
      <ReactApp injector={injector}/>,
      document.getElementById(containerId)
    );
  }
}

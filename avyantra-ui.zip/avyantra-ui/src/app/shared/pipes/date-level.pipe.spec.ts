import { DateLevelPipe } from './date-level.pipe';

describe('DateLevelPipe', () => {
  it('create an instance', () => {
    const pipe = new DateLevelPipe();
    expect(pipe).toBeTruthy();
  });
});

import { ButtonCursorDirective } from './button-cursor.directive';

describe('ButtonCursorDirective', () => {
  it('should create an instance', () => {
    const directive = new ButtonCursorDirective();
    expect(directive).toBeTruthy();
  });
});

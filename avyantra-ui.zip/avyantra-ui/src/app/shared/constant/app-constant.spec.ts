import { AppConstant } from './app-constant';

describe('AppConstant', () => {
  it('should create an instance', () => {
    expect(new AppConstant()).toBeTruthy();
  });
});

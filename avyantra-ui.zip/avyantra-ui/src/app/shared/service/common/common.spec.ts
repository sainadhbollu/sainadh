import { Common } from './common';

describe('Common', () => {
  it('should create an instance', () => {
    expect(new Common()).toBeTruthy();
  });
});

export const environment = {
    production: false,
    server_url: "http://localhost:8080",
     server_folder:'aspldev/'
  };
export const environment = {
  production: true,
  server_url: "http://13.234.214.254:8081/",
  server_folder:''
};
